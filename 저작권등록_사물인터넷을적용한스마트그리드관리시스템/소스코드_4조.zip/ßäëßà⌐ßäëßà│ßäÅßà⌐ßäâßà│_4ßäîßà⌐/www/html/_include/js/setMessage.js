function setMessage(arg) {
    var param = {};
    param.token = arg;
	document.getElementById("temp").value = arg;
} 


